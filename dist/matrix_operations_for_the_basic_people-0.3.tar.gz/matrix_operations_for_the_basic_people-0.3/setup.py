#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from setuptools import setup

setup(name='matrix_operations_for_the_basic_people',
      version='0.3',
      description='Basic matrix operations',
      packages=['matrix_operations'],
      author = 'Jimmy Lin',
      author_email='jimmylinzhe@hotmail.com',
      zip_safe = False)

